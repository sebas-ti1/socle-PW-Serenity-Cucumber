// déclenchement du filtre sur une lettre sur la page lexique
function filterLetter(lettre) {
    // si on reclique sur la lettre, alors la recherche par filtre de lettre se réinitialise.
    // Suppression de la surbrillance sur la lettre
    if ($('#input-hidden-letter').val() === lettre) {
        $('#input-hidden-letter').val('');
        $('#lettre-' + lettre)[0].style.color = "white";
        $('#lettre-' + lettre)[0].style.background = "none";
    } else {
        // Si on filtre sur une autre lettre
        if ($('#input-hidden-letter').val() !== '') {
            $('#lettre-' + $('#input-hidden-letter').val())[0].style.color = "white";
            $('#lettre-' + $('#input-hidden-letter').val())[0].style.background = "none";
            $('#lettre-' + lettre)[0].style.color = "#545454";
            $('#lettre-' + lettre)[0].style.background = "white";

            // si on filtre pour la première fois sur une lettre
        } else {
            $('#lettre-' + lettre)[0].style.color = "#545454";
            $('#lettre-' + lettre)[0].style.background = "white";
        }

        $('#input-hidden-letter').val(lettre);
    }
    //validation du formulaire
    $('#form-lexique').submit();
}

function filterFaq(faq_cat) {

    var inputCache = $('#input-hidden-faq_cat').val();

    if (inputCache.includes(faq_cat)) {

        // On enleve faq_cat de l'input caché
        inputCache = inputCache.replace(faq_cat , "");
        inputCache = inputCache.replace( ";;", ";");

    } else {
        // on ajoute faq_cat a l'input caché (avec un séparateur de type , ou ;
        if (inputCache == "") {
            inputCache = faq_cat;
        } else {
            inputCache = inputCache + ';' + faq_cat;
        }
        inputCache = inputCache.replace( ";;", ";");
    }
    if(inputCache == ";"){
        inputCache = null; 
    }
    // On submit le form
    $('#input-hidden-faq_cat').val(inputCache);
    $('#form-faq').submit();

}