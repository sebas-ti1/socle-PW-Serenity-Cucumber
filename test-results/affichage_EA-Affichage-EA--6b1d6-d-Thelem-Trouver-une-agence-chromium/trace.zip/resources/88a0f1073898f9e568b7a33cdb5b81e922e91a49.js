var captchaRdv;
var captchaCourtage;
var captchaService;
var captchaReclamation;
var divError;
var g_site_key = '6Lcd-N0UAAAAAO01Ie5HLlxwhzL_XdIYzsHgdo6Q'; // prod
//g_site_key = '6Lfe0YgiAAAAAHoj188W-fTM49_2J-ppu-QXGjLN'; // FI local

window.onload = function () {
    /*   var $recaptcha = document.querySelector('#g-recaptcha-response');
   
       if ($recaptcha) {
           $recaptcha.setAttribute("required", "required");
       }
       var $recaptcha1 = document.querySelector('#g-recaptcha-response-1');
   
       if ($recaptcha1) {
           $recaptcha1.setAttribute("required", "required");
       }
       var $recaptcha2 = document.querySelector('#g-recaptcha-response-2');
   
       if ($recaptcha2) {
           $recaptcha2.setAttribute("required", "required");
           //$recaptcha2.setCustomValidity("Veuillez renseigner le captcha");
       }*/
    if (document.querySelector('.recaptcha-error-message-courtage')) {
        document.querySelector('.recaptcha-error-message-courtage').style.display = "none";
    }
    if (document.querySelector('.recaptcha-error-message-reclamation')) {
        document.querySelector('.recaptcha-error-message-reclamation').style.display = "none";
    }
    if (document.querySelector('.recaptcha-error-message-service')) {
        document.querySelector('.recaptcha-error-message-service').style.display = "none";
    }
    if (document.querySelector('.recaptcha-error-message-contact')) {
        document.querySelector('.recaptcha-error-message-contact').style.display = "none";
    }

};

var onloadCallback = function () {
    if (document.getElementById('captcha-contact')) {
        captchaRdv = grecaptcha.render('captcha-contact', {
            'sitekey': g_site_key,
            'callback': captcha_filled_contact,
        });
        // console.log('captcha-contact recaptch loaded', grecaptcha, g_site_key, captcha_filled_contact);
    }
    if (document.getElementById('captcha-form-courtage')) {
        captchaCourtage = grecaptcha.render('captcha-form-courtage', {
            'sitekey': g_site_key,
            'callback': captcha_filled_courtage,
        });
    }
    if (document.getElementById('captcha-form-service')) {
        captchaService = grecaptcha.render('captcha-form-service', {
            'sitekey': g_site_key,
            'callback': captcha_filled_service,
        });
    }
    if (document.getElementById('captcha-form-reclamation')) {
        // Timeout uniquement pour la popup
        setTimeout(function() {
            renderReclamationCaptcha();
        }, 100);

    }
};

function renderReclamationCaptcha() {
    captchaReclamation = grecaptcha.render('captcha-form-reclamation', {
        'sitekey': g_site_key,
        'callback': captcha_filled_new_reclamation,
    });
}

function valideCaptcha(name, form) {
    var gresp = grecaptcha.getResponse(name);
    if (!gresp) {
        return false;
    }
    form.append('<input type="hidden" name="gresp" id="gresp" value="'+gresp+'" />');
    form.append('<input type="hidden" name="gsec" id="gsec" value="'+g_site_key+'" />');
    form.append('<input type="hidden" name="gurl" id="gurl" value="'+scriptParams.url_captcha+'" />');
    return true;
    // Bypass js verification because of gCaptcha verification security policy
    var valide = false;
    jQuery.ajax({
        type: "POST",
        url: ipAjaxVar.ajaxurl,
        dataType: 'json',
        async: false,
        data: {
            "secret": g_site_key,
            "response": grecaptcha.getResponse(name),
            "url": scriptParams.url_captcha
        },
        success: function (data) {
            form.append('<input type="hidden" name="gresp" id="gresp" value="'+gresp+'" />');
            form.append('<input type="hidden" name="gsec" id="gsec" value="'+g_site_key+'" />');
            form.append('<input type="hidden" name="gurl" id="gurl" value="'+scriptParams.url_captcha+'" />');
            valide = data.reCatpchaResponse.success;
        },
        error: function () {
            console.log('Erreur Captcha');
        }
    });
    return valide;
}

/* fonction qui s'exécute lorsque l'utilisateur remplit correctement le reCapcha sur le formulaire de courtage*/
function captcha_filled_courtage() {
    // console.log('captcha_filled_courtage allowSubmit : true');
    divError = document.querySelector('#captcha-form-courtage').parentNode;
    divError.classList.remove('recaptcha-error');
    document.querySelector('.recaptcha-error-message-courtage').style.display = "none";
}
/* fonction qui s'exécute lorsque l'utilisateur remplit correctement le reCapcha sur le formulaire de réclamation*/
function captcha_filled_reclamation() {
    // console.log('captcha_filled_reclamation allowSubmit : true');
    divError = document.querySelector('#captcha-form-reclamation').parentNode;
    divError.classList.remove('recaptcha-error');
    document.querySelector('.recaptcha-error-message-reclamation').style.display = "none";
}
/* fonction qui s'exécute lorsque l'utilisateur remplit correctement le reCapcha sur le formulaire service*/
function captcha_filled_service() {
    // console.log('captcha_filled_service allowSubmit : true');
    divError = document.querySelector('#captcha-form-service').parentNode;
    divError.classList.remove('recaptcha-error');
    document.querySelector('.recaptcha-error-message-service').style.display = "none";
}

/* fonction qui s'exécute lorsque l'utilisateur remplit correctement le reCapcha sur le formulaire service*/
function captcha_filled_contact() {
    // console.log('captcha_filled_service allowSubmit : true');
    divError = document.querySelector('#captcha-contact').parentNode;
    divError.classList.remove('recaptcha-error');
    document.querySelector('.recaptcha-error-message-contact').style.display = "none";
}

/* new fi reclamation form */
function captcha_filled_new_reclamation() {
    // console.log('captcha_filled_new_reclamation allowSubmit : true');
    divError = document.querySelector('#captcha-form-reclamation').parentNode;
    divError.classList.remove('recaptcha-error');
    document.querySelector('.recaptcha-error-message-reclamation').style.display = "none";
}

function valideFormContact() {
    if (!valideCaptcha(captchaRdv, $("#form-prise-rdv"))) {
        divError = document.querySelector('#captcha-contact').parentNode;
        divError.classList.add('recaptcha-error');
        document.querySelector('.recaptcha-error-message-contact').style.display = "block";
    } else {
        if ($("#form-prise-rdv")[0].checkValidity()) {
            var form = document.getElementById("form-prise-rdv")
            form.submit();
        } else {
            $("#form-prise-rdv").find("#hidden-submit-form-contact").click();
        }
    }
}

function validateFormDemandeRDV() {
    const form = $('.agence-page__wrapper.new #form-prise-rdv');

    const triggerReport = (input, message = "Veuillez renseigner ce champ.") => {
        $('html, body').animate({
            scrollTop: form.offset().top - 200
        }, 500);
        setTimeout(() => {
            input.setCustomValidity(message);
            input.reportValidity();
            setTimeout(() => {
                input.setCustomValidity("");
            }, 2000);
        }, 200);
    }

    if (!valideCaptcha(captchaRdv, form)) {
        divError = document.querySelector('#captcha-contact').parentNode;
        divError.classList.add('recaptcha-error');
        document.querySelector('.recaptcha-error-message-contact').style.display = "block";
    } else {
        let valid = true;

        $(form).find('.owl-item.active [data-required]').each(function(i, input) {
            if ( !$(input).is(':visible') ) return;

            if ($(input).attr('type') === 'radio') {
                const name = $(input).attr('name');
                if (!$('input[name="' + name + '"]:checked').length) {
                    triggerReport(input, "Veuillez sélectionner l'une de ces options.");
                    valid = false;
                    return false;
                }
            }

            if (!$(input).val() || $(input).val().trim().length === 0 ) {
                triggerReport(input);
                valid = false;
                return false;
            }
        });

        if ( valid && form[0].checkValidity() ) {
            form.submit();
        }
    }
}
